package inheritance2;

public abstract class Duck {

	public abstract void display();
	public void fly()
	{
		System.out.println("Duck is Flying");
	}
	public void swim() {
		System.out.println("Duck is Swimming...");
	}
	
	public void quack()
	{
		System.out.println("Duck is Quacking...");
	}
	
}
