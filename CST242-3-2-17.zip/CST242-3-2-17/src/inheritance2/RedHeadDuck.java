package inheritance2;

public class RedHeadDuck extends Duck {

	@Override
	public void display() 
	{
		System.out.println("Red Head Duck Displaying");

	}


}
