package inheritance2;

public class Demo 
{

	public static void main(String[] args) 
	{
	
		Duck md = new MallardDuck();
		Duck rhd = new RedHeadDuck();
		Duck rd = new RubberDuck();
		md.display();
		md.swim();
		md.quack();
		System.out.println("---___---___---");
		rhd.display();
		rhd.swim();
		rhd.quack();
		System.out.println("---___---___---");
		rd.display();
		rd.swim();
		rd.quack();
		
	}
	
}
