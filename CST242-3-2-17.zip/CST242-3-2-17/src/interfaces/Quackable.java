package interfaces;

public interface Quackable 
{

	default void quack()
	{
		System.out.println("Duck is Quacking");
	}
	
}
