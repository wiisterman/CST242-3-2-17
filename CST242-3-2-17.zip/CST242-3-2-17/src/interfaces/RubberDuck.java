package interfaces;

public class RubberDuck extends Duck implements Quackable {

	@Override
	public void display() {
		System.out.println("Rubber Duck Display");
	}

	@Override
	public void quack() {
		System.out.println("Rubber Duck Squeaks");
	}

}
