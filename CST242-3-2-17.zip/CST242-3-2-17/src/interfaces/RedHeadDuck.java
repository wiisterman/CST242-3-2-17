package interfaces;

public class RedHeadDuck extends Duck implements Quackable, Flyable{

	@Override
	public void display() 
	{
		System.out.println("Red Head Duck Displaying");
	}


}
