package interfaces;

public class Demo 
{

	public static void main(String[] args) 
	{
	
		MallardDuck md = new MallardDuck();
		RedHeadDuck rhd = new RedHeadDuck();
		RubberDuck rd = new RubberDuck();
		DecoyDuck dd = new DecoyDuck();
		md.display();
		md.swim();
		md.quack();
		System.out.println("---_ _---_ _---");
		rhd.display();
		rhd.swim();
		rhd.quack();
		System.out.println("---_ _---_ _---");
		rd.display();
		rd.swim();
		rd.quack();
		System.out.println("---_ _---_ _---");
		dd.display();
		dd.swim();
		
	}
	
}
