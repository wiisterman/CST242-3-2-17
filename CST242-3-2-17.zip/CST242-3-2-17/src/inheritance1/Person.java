package inheritance1;

public abstract class Person
//Abstract class can't be created EX: =| Person p1 = new Person();
//By having an Abstract class, you can have abstract methods in Abstract classes
//Any non private member will be passed
{

	private String name;
	private String id;

	public Person(String name, String id) {
		super();
		this.name = name;
		this.id = id;
	}

	public abstract String getInfo();//Abstract Method without Implementation;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getId() {
		return id;
	}

	public void setGpa(String id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "Person\nName: " + name + "\nGPA: " + id;
	}


}
