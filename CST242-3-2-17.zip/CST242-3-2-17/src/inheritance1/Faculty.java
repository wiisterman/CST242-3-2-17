package inheritance1;

public class Faculty extends Person {

	private double salary;

	public Faculty(String name, String id, double salary) {
		super(name, id);
		this.salary = salary;
	}

	@Override
	public String getInfo() {
		// TODO Auto-generated method stub
		return "\nName: " + getName() + "\tID: " + getId() + "\tSalary: "+getSalary();
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "Faculty [salary=" + salary + "]";
	}

}
