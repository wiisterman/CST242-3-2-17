package inheritance1;

public class Demo 
{

	public static void main(String[] args) 
	{
		
		Student s1 = new Student("Kyle","1",3.9);
		Faculty f1 = new Faculty("John","2",12300);
		
		System.out.println(s1.getInfo());
		System.out.println(f1.getInfo());
	}
	
}
